# Revdeps

## Failed to check (23)

|package        |version |error |warning |note |
|:--------------|:-------|:-----|:-------|:----|
|NA             |?       |      |        |     |
|NA             |?       |      |        |     |
|FAMetA         |0.1.5   |1     |        |     |
|NA             |?       |      |        |     |
|NA             |?       |      |        |     |
|genekitr       |?       |      |        |     |
|ggPMX          |?       |      |        |     |
|NA             |?       |      |        |     |
|grandR         |?       |      |        |     |
|lilikoi        |?       |      |        |     |
|MarketMatching |?       |      |        |     |
|MARVEL         |?       |      |        |     |
|NA             |?       |      |        |     |
|NA             |?       |      |        |     |
|numbat         |?       |      |        |     |
|oHMMed         |?       |      |        |     |
|OlinkAnalyze   |?       |      |        |     |
|NA             |?       |      |        |     |
|NA             |?       |      |        |     |
|SCpubr         |?       |      |        |     |
|tidySEM        |?       |      |        |     |
|NA             |?       |      |        |     |
|NA             |?       |      |        |     |

## New problems (3)

|package                                  |version |error  |warning |note |
|:----------------------------------------|:-------|:------|:-------|:----|
|[duke](problems.md#duke)                 |0.0.1   |__+1__ |        |     |
|[ggside](problems.md#ggside)             |0.2.2   |__+1__ |        |     |
|[WoodSimulatR](problems.md#woodsimulatr) |0.6.0   |__+1__ |__+1__  |     |

