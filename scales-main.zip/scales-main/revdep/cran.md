## revdepcheck results

We checked 904 reverse dependencies (893 from CRAN + 11 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 3 new problems
 * We failed to check 12 packages

Issues with CRAN packages are summarised below.

### New problems
(This reports the first line of each new failure)

* duke
  checking tests ... ERROR

* ggside
  checking tests ... ERROR

* WoodSimulatR
  checking examples ... ERROR
  checking re-building of vignette outputs ... WARNING

### Failed to check

* FAMetA         (NA)
* genekitr       (NA)
* ggPMX          (NA)
* grandR         (NA)
* lilikoi        (NA)
* MarketMatching (NA)
* MARVEL         (NA)
* numbat         (NA)
* oHMMed         (NA)
* OlinkAnalyze   (NA)
* SCpubr         (NA)
* tidySEM        (NA)
