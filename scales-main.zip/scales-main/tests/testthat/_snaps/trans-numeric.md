# Boxcox gives error for negative values

    Code
      trans$trans(-10:10)
    Condition
      Error in `trans$trans()`:
      ! `transform_boxcox()` must be given only positive values
      i Consider using `transform_modulus()` instead?

---

    Code
      trans$trans(-10:10)
    Condition
      Error in `trans$trans()`:
      ! `transform_boxcox()` must be given only positive values
      i Consider using `transform_modulus()` instead?

