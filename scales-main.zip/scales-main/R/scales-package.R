#' @keywords internal
#' @importFrom R6 R6Class
#' @import rlang
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom glue glue
#' @importFrom lifecycle deprecate_soft
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
